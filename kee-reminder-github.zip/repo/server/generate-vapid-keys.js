// Run once: node generate-vapid-keys.js
// Prints a public/private VAPID keypair. Put both into your .env file
// (see .env.example) — never commit the private key or share it.
const webpush = require('web-push');

const keys = webpush.generateVAPIDKeys();
console.log('\nAdd these to your .env file (or your host\'s environment variables):\n');
console.log('VAPID_PUBLIC_KEY=' + keys.publicKey);
console.log('VAPID_PRIVATE_KEY=' + keys.privateKey);
console.log('\nThe PUBLIC key also needs to be pasted into the app\'s "Background alerts" settings.\n');
