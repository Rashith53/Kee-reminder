// Minimal file-based storage: one JSON file holding all devices.
// Fine for personal/small-scale use. If your host wipes the filesystem on
// redeploy (some serverless platforms do), point DATA_FILE at a persistent
// disk/volume if your host offers one.
const fs = require('fs');
const path = require('path');

const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');

function load() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    return { devices: {} };
  }
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

function getDb() {
  if (!getDb._cache) getDb._cache = load();
  return getDb._cache;
}

function persist() {
  save(getDb());
}

function upsertSubscription(deviceId, subscription) {
  const db = getDb();
  if (!db.devices[deviceId]) db.devices[deviceId] = { alarms: [] };
  db.devices[deviceId].subscription = subscription;
  persist();
}

function setAlarms(deviceId, alarms) {
  const db = getDb();
  if (!db.devices[deviceId]) db.devices[deviceId] = { alarms: [] };
  // alarms: [{id, title, due (ms epoch), repeat}]
  db.devices[deviceId].alarms = alarms;
  persist();
}

function removeDevice(deviceId) {
  const db = getDb();
  delete db.devices[deviceId];
  persist();
}

function allDevices() {
  return getDb().devices;
}

function updateAlarm(deviceId, alarmId, patch) {
  const db = getDb();
  const dev = db.devices[deviceId];
  if (!dev) return;
  const a = dev.alarms.find((x) => x.id === alarmId);
  if (a) Object.assign(a, patch);
  persist();
}

module.exports = { upsertSubscription, setAlarms, removeDevice, allDevices, updateAlarm };
