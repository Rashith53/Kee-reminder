require('dotenv').config();
const express = require('express');
const cors = require('cors');
const webpush = require('web-push');
const store = require('./storage');

const PORT = process.env.PORT || 3000;
const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:you@example.com';
// Comma-separated list of origins allowed to call this server (your GitHub Pages URL).
// e.g. "https://yourusername.github.io"
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '*').split(',').map((s) => s.trim());
// Simple shared-secret so random people can't post fake subscriptions/alarms to your server.
// Set this to any long random string, and put the same value in the app's settings.
const SHARED_SECRET = process.env.SHARED_SECRET || '';

if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
  console.error('Missing VAPID_PUBLIC_KEY / VAPID_PRIVATE_KEY. Run: npm run generate-keys');
  process.exit(1);
}
webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

const app = express();
app.use(express.json());
app.use(
  cors({
    origin: ALLOWED_ORIGINS.includes('*') ? true : ALLOWED_ORIGINS,
  })
);

function checkSecret(req, res, next) {
  if (!SHARED_SECRET) return next(); // no secret configured = open (fine for quick personal testing only)
  const given = req.header('x-app-secret') || '';
  if (given !== SHARED_SECRET) return res.status(401).json({ error: 'bad secret' });
  next();
}

app.get('/api/health', (req, res) => res.json({ ok: true, time: Date.now() }));

app.get('/api/vapid-public-key', (req, res) => {
  res.json({ publicKey: VAPID_PUBLIC_KEY });
});

app.post('/api/subscribe', checkSecret, (req, res) => {
  const { deviceId, subscription } = req.body || {};
  if (!deviceId || !subscription || !subscription.endpoint) {
    return res.status(400).json({ error: 'deviceId and subscription are required' });
  }
  store.upsertSubscription(deviceId, subscription);
  res.json({ ok: true });
});

app.post('/api/unsubscribe', checkSecret, (req, res) => {
  const { deviceId } = req.body || {};
  if (!deviceId) return res.status(400).json({ error: 'deviceId is required' });
  store.removeDevice(deviceId);
  res.json({ ok: true });
});

// Full sync: the app sends its complete current list of upcoming (not-done) task alarms
// for this device every time something changes. Simpler and more robust than diffing.
app.post('/api/alarms', checkSecret, (req, res) => {
  const { deviceId, alarms } = req.body || {};
  if (!deviceId || !Array.isArray(alarms)) {
    return res.status(400).json({ error: 'deviceId and alarms[] are required' });
  }
  for (const a of alarms) {
    if (!a.id || !a.title || typeof a.due !== 'number') {
      return res.status(400).json({ error: 'each alarm needs id, title, due (ms epoch number)' });
    }
  }
  // Preserve fired-state for alarms the client still knows about, so an in-flight
  // fire isn't lost on the next sync; new/changed alarms start unfired.
  const existing = store.allDevices()[deviceId];
  const prevById = {};
  if (existing) for (const a of existing.alarms || []) prevById[a.id] = a;
  const merged = alarms.map((a) => {
    const prev = prevById[a.id];
    const same = prev && prev.due === a.due && prev.repeat === a.repeat;
    return { id: a.id, title: a.title, due: a.due, repeat: a.repeat || 'none', fired: same ? !!prev.fired : false };
  });
  store.setAlarms(deviceId, merged);
  res.json({ ok: true, count: merged.length });
});

function nextDue(due, repeat) {
  const d = new Date(due);
  if (repeat === 'daily') d.setDate(d.getDate() + 1);
  else if (repeat === 'weekly') d.setDate(d.getDate() + 7);
  else if (repeat === 'monthly') d.setMonth(d.getMonth() + 1);
  else return null;
  return d.getTime();
}

const GRACE_MS = 15 * 60 * 1000; // ignore alarms more than 15 min overdue (e.g. server was down)
const CHECK_EVERY_MS = 30 * 1000;

async function tick() {
  const now = Date.now();
  const devices = store.allDevices();
  deviceLoop:
  for (const [deviceId, dev] of Object.entries(devices)) {
    if (!dev.subscription) continue;
    let deviceRemoved = false;
    for (const alarm of dev.alarms || []) {
      if (alarm.fired) continue;
      if (alarm.due > now) continue;
      if (now - alarm.due > GRACE_MS) {
        alarm.fired = true; // too late, skip silently rather than spamming a stale alert
        continue;
      }
      try {
        await webpush.sendNotification(
          dev.subscription,
          JSON.stringify({ title: '🔔 Task reminder', body: alarm.title, tag: 'kee-' + alarm.id })
        );
      } catch (err) {
        if (err.statusCode === 404 || err.statusCode === 410) {
          // subscription is gone (user revoked permission / uninstalled) — drop it entirely
          store.removeDevice(deviceId);
          deviceRemoved = true;
          continue deviceLoop;
        } else {
          console.error('Push failed for', deviceId, alarm.id, err.message);
        }
      }
      const next = nextDue(alarm.due, alarm.repeat);
      if (next) {
        alarm.due = next;
        alarm.fired = false;
      } else {
        alarm.fired = true;
      }
    }
    store.setAlarms(deviceId, dev.alarms || []);
  }
}

setInterval(() => {
  tick().catch((err) => console.error('tick error:', err));
}, CHECK_EVERY_MS);

app.listen(PORT, () => console.log(`Kee Reminder push server listening on :${PORT}`));

module.exports = { app, tick, nextDue };
